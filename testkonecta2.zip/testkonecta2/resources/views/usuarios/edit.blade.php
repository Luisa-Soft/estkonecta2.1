Editar usuario
<form action="" method="POST" enctype="multipart/form-data">

<label for="Nombre">{{'Nombre'}}</label>
<input class="form-control" type="text" name="us_name" id="us_name">
<input class="form-control" type="submit" value="Agregar">
</form>